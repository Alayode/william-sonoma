<?php
// Text
$_['text_all'] = 'Show All';
$_['name'] = 'Home';
$_['text_blog'] = 'Blogs';