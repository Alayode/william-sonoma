<?php
// Heading
$_['heading_title']     = 'NewsLetter';

// Entry
$_['entry_email']          = 'E-Mail';

// Email
$_['email_subject']       = 'Welcome';
$_['email_content']       = 'Thank you for Subscription';


